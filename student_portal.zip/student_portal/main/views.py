from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.http import HttpResponse,JsonResponse
from reportlab.pdfgen import canvas
from .models import *
from .forms import *
def home(r):return render(r,'home.html')
def user_login(r):
    if r.method=='POST':
        u=r.POST['username'];p=r.POST['password']
        user=authenticate(username=u,password=p)
        if user:
            login(r,user)
            if user.is_superuser: return redirect('admin_dashboard')
            elif hasattr(user,'staffprofile'): return redirect('staff_dashboard')
            else: return redirect('parent_dashboard')
    return render(r,'login.html')
def user_logout(r): logout(r);return redirect('login')

@login_required
def admin_dashboard(r):
    return render(r,'admin_dashboard.html',{"staff":StaffProfile.objects.all(),"students":Student.objects.count()})

@login_required
def staff_dashboard(r):
    return render(r,'staff_dashboard.html',{"students":Student.objects.all()})

@login_required
def parent_dashboard(r):
    c=Student.objects.get(parent=r.user)
    att=Attendance.objects.filter(student=c); mk=Marks.objects.filter(student=c)
    total=att.count();present=att.filter(status='Present').count()
    percent=round((present/total)*100,2) if total else 0
    return render(r,'parent_dashboard.html',{"child":c,"attendance":att,"marks":mk,"percent":percent})

@login_required
def add_student(r):
    f=StudentForm(r.POST or None); 
    if f.is_valid(): f.save();return redirect('staff_dashboard')
    return render(r,'add_student.html',{"form":f})

@login_required
def edit_student(r,id):
    s=Student.objects.get(id=id); f=StudentForm(r.POST or None,instance=s)
    if f.is_valid(): f.save();return redirect('staff_dashboard')
    return render(r,'edit_student.html',{"form":f})

@login_required
def delete_student(r,id): Student.objects.get(id=id).delete();return redirect('staff_dashboard')

@login_required
def mark_attendance(r,id):
    s=Student.objects.get(id=id); f=AttendanceForm(r.POST or None)
    if f.is_valid(): a=f.save(commit=False);a.student=s;a.save();return redirect('staff_dashboard')
    return render(r,'mark_attendance.html',{"form":f})

@login_required
def upload_marks(r,id):
    s=Student.objects.get(id=id); f=MarksForm(r.POST or None)
    if f.is_valid(): m=f.save(commit=False);m.student=s;m.save();return redirect('staff_dashboard')
    return render(r,'upload_marks.html',{"form":f})

@login_required
def generate_report(r):
    c=Student.objects.get(parent=r.user)
    att=Attendance.objects.filter(student=c);mk=Marks.objects.filter(student=c)
    res=HttpResponse(content_type='application/pdf')
    res['Content-Disposition']='attachment; filename="report.pdf"'
    p=canvas.Canvas(res);p.drawString(100,800,f"Report for {c.name}")
    y=780
    for a in att: p.drawString(100,y,f"{a.date} - {a.status}");y-=20
    p.showPage();p.save();return res

@login_required
def api_student_data(r):
    c=Student.objects.get(parent=r.user)
    return JsonResponse({"student":c.name})
