from django.db import models
from django.contrib.auth.models import User

class Student(models.Model):
    name=models.CharField(max_length=100)
    roll_no=models.CharField(max_length=20,unique=True)
    class_name=models.CharField(max_length=50)
    parent=models.ForeignKey(User,on_delete=models.CASCADE,related_name='parent_user')

class Attendance(models.Model):
    student=models.ForeignKey(Student,on_delete=models.CASCADE)
    date=models.DateField()
    status=models.CharField(max_length=10)

class Marks(models.Model):
    student=models.ForeignKey(Student,on_delete=models.CASCADE)
    subject=models.CharField(max_length=100)
    marks=models.IntegerField()
    exam_name=models.CharField(max_length=100)

class StaffProfile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    assigned_class=models.CharField(max_length=50)
